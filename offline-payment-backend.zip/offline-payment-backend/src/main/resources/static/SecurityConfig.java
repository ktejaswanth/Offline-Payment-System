package com.offlinepay.backend;

public class SecurityConfig {

}
