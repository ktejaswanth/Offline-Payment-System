package com.offlinepay.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfflinePaymentBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
